package ukrim.co.id.serversideukrim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServersideUkrimApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServersideUkrimApplication.class, args);
                System.out.println("Serverside is running....");
	}

}
