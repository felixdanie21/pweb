/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ukrim.co.id.serversideukrim.model;

/**
 *
 * @author MSI-JO
 */
public class Region {
    
    private Long id; // PK
    private String name; // Not_null
    
}
