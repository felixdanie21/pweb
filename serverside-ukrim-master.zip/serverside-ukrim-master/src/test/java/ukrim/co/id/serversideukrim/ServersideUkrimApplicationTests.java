package ukrim.co.id.serversideukrim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServersideUkrimApplicationTests {

	@Test
	void contextLoads() {
	}

}
